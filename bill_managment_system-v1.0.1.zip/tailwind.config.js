module.exports = {
  mode: "jit",
  content: ["./src/**/**/*.{js,ts,jsx,tsx,html,mdx}", "./src/**/*.{js,ts,jsx,tsx,html,mdx}"],
  darkMode: "class",
  theme: {
    screens: { md: { max: "1050px" }, sm: { max: "550px" } },
    extend: {
      colors: {
        white: { A700: "#ffffff" },
        black: { 900: "#000000" },
        blue_gray: { 100: "#d9d9d9" },
        gray: { 900: "#1c1c1c" },
        deep_purple: { "50_cc": "#efedffcc" },
      },
      boxShadow: { xs: "0px 8px  21px 0px #00000028" },
      backgroundImage: {
        gradient: "linear-gradient(134deg, #d8ca4a,#e8eb2c)",
        gradient1: "linear-gradient(180deg, #f8cb56,#f4ec38)",
        gradient2: "linear-gradient(180deg, #f8cb56,#eef30dd3)",
      },
      fontFamily: { poppins: "Poppins", inter: "Inter" },
      textShadow: { ts: "0px 4px  4px #0000004c", ts1: "0px 4px  4px #0000003f" },
    },
  },
  plugins: [require("@tailwindcss/forms")],
};
