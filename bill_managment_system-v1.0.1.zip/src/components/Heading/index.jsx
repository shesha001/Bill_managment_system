import React from "react";

const sizes = {
  s: "text-3xl font-bold",
  md: "text-4xl font-bold",
  xs: "text-xl font-bold",
};

const Heading = ({ children, className = "", size = "md", as, ...restProps }) => {
  const Component = as || "h6";

  return (
    <Component className={`text-white-A700 font-poppins ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { Heading };
