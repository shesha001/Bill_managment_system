import React from "react";

const sizes = {
  xs: "text-sm font-normal",
  lg: "text-5xl font-normal",
  s: "text-base font-normal",
  xl: "text-[64px] font-normal",
  md: "text-2xl font-normal",
};

const Text = ({ children, className = "", as, size = "lg", ...restProps }) => {
  const Component = as || "p";

  return (
    <Component className={`text-black-900 font-inter ${className} ${sizes[size]}`} {...restProps}>
      {children}
    </Component>
  );
};

export { Text };
