import React from "react";
import PropTypes from "prop-types";

const shapes = {
  round: "rounded-[16px]",
  square: "rounded-[0px]",
};
const variants = {
  fill: {
    deep_purple_50_cc: "bg-deep_purple-50_cc",
    blue_gray_100: "bg-blue_gray-100",
  },
};
const sizes = {
  xs: "h-[54px]",
  sm: "h-[58px]",
  xl: "h-[77px]",
  md: "h-[67px]",
  "2xl": "h-[101px]",
  lg: "h-[71px]",
};

const Input = React.forwardRef(
  (
    {
      className = "",
      name = "",
      placeholder = "",
      type = "text",
      children,
      label = "",
      prefix,
      suffix,
      onChange,
      shape = "square",
      variant = "fill",
      size = "lg",
      color = "blue_gray_100",
      ...restProps
    },
    ref,
  ) => {
    const handleChange = (e) => {
      if (onChange) onChange(e?.target?.value);
    };

    return (
      <>
        <div
          className={`${className} flex items-center justify-center ${shapes[shape] || ""} ${variants[variant]?.[color] || variants[variant] || ""} ${sizes[size] || ""}`}
        >
          {!!label && label}
          {!!prefix && prefix}
          <input ref={ref} type={type} name={name} onChange={handleChange} placeholder={placeholder} {...restProps} />
          {!!suffix && suffix}
        </div>
      </>
    );
  },
);

Input.propTypes = {
  className: PropTypes.string,
  name: PropTypes.string,
  placeholder: PropTypes.string,
  type: PropTypes.string,
  label: PropTypes.string,
  prefix: PropTypes.node,
  suffix: PropTypes.node,
  shape: PropTypes.oneOf(["round", "square"]),
  size: PropTypes.oneOf(["xs", "sm", "xl", "md", "2xl", "lg"]),
  variant: PropTypes.oneOf(["fill"]),
  color: PropTypes.oneOf(["deep_purple_50_cc", "blue_gray_100"]),
};

export { Input };
