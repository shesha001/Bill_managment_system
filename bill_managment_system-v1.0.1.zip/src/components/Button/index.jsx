import React from "react";
import PropTypes from "prop-types";

const shapes = {
  round: "rounded-[16px]",
};
const variants = {
  gradient: {
    lime_400_yellow_500_01: "bg-gradient shadow-xs text-white-A700",
  },
};
const sizes = {
  xs: "h-[49px] px-[35px] text-xl",
  sm: "h-[57px] px-[35px] text-xl",
  md: "h-[65px] pl-[25px] pr-[35px] text-4xl",
};

const Button = ({
  children,
  className = "",
  leftIcon,
  rightIcon,
  shape = "round",
  variant = "gradient",
  size = "md",
  color = "",
  ...restProps
}) => {
  return (
    <button
      className={`${className} flex items-center justify-center text-center cursor-pointer text-white-A700 font-bold bg-gradient shadow-xs rounded-[16px] ${(shape && shapes[shape]) || ""} ${(size && sizes[size]) || ""} ${(variant && variants[variant]?.[color]) || ""}`}
      {...restProps}
    >
      {!!leftIcon && leftIcon}
      {children}
      {!!rightIcon && rightIcon}
    </button>
  );
};

Button.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  leftIcon: PropTypes.node,
  rightIcon: PropTypes.node,
  shape: PropTypes.oneOf(["round"]),
  size: PropTypes.oneOf(["xs", "sm", "md"]),
  variant: PropTypes.oneOf(["gradient"]),
  color: PropTypes.oneOf(["lime_400_yellow_500_01"]),
};

export { Button };
