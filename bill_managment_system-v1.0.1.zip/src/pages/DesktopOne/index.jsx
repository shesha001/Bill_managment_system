import React from "react";
import { Helmet } from "react-helmet";
import { Button, Heading, Input, Text, Img } from "../../components";

export default function DesktopOnePage() {
  return (
    <>
      <Helmet>
        <title>bill managment system</title>
        <meta name="description" content="Web site created using create-react-app" />
      </Helmet>
      <div className="flex flex-row justify-start w-full bg-white-A700">
        <div className="flex flex-row justify-between items-start w-full mx-auto max-w-[1302px]">
          <div className="flex flex-col items-start justify-start w-[52%]">
            <Img src="images/img_ellipse_3_227x346.png" alt="image" className="w-[52%] ml-[202px] object-cover" />
            <div className="flex flex-row justify-between items-center w-full mt-7">
              <Img src="images/img_ellipse_2_426x237.png" alt="image_one" className="w-[36%] object-cover" />
              <div className="h-[310px] w-[52%] bg-gradient2 rounded-[50%]" />
            </div>
            <div className="h-[310px] w-[52%] mt-[71px] ml-[134px] bg-gradient1 rounded-[50%]" />
          </div>
          <div className="flex flex-col items-center justify-start w-[38%] mt-[172px]">
            <a href="#">
              <Heading size="s" as="h1" className="!text-black-900 uppercase">
                Login
              </Heading>
            </a>
            <div className="flex flex-col items-start justify-start w-full mt-[97px]">
              <div className="flex flex-row justify-start w-full">
                <div className="flex flex-col items-start justify-start w-full">
                  <Text size="s" as="p" className="ml-[35px] !text-gray-900 z-[1]">
                    Username
                  </Text>
                  <div className="flex flex-col items-start justify-start w-full mt-[-19px]">
                    <Img src="images/img_frame.svg" alt="image_two" className="h-[31px] ml-px z-[1]" />
                    <Input
                      color="deep_purple_50_cc"
                      size="xl"
                      shape="round"
                      name="edittext"
                      className="w-full mt-[-7px]"
                    />
                  </div>
                </div>
              </div>
              <div className="flex flex-row justify-start w-full mt-[19px]">
                <div className="flex flex-col items-start justify-start w-full">
                  <div className="flex flex-row justify-start items-center ml-[18px] gap-[7px]">
                    <Img src="images/img_vector.svg" alt="vector_one" className="h-[25px]" />
                    <Text size="s" as="p" className="!text-gray-900">
                      Password
                    </Text>
                  </div>
                  <Input color="deep_purple_50_cc" size="md" shape="round" name="edittext_one" className="w-full" />
                </div>
              </div>
              <Heading size="xs" as="h2" className="mt-1 !text-black-900">
                forgot password
              </Heading>
            </div>
            <Button size="sm" color="lime_400_yellow_500_01" className="mt-[35px] min-w-[139px]">
              Login{" "}
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
