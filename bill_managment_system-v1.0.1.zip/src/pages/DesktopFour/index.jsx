import React from "react";
import { Helmet } from "react-helmet";
import { Button, Input, Heading, Text, Img } from "../../components";

export default function DesktopFourPage() {
  return (
    <>
      <Helmet>
        <title>bill managment system</title>
        <meta name="description" content="Web site created using create-react-app" />
      </Helmet>
      <div className="flex flex-row justify-center w-full pb-[136px] bg-white-A700">
        <div className="flex flex-col items-start justify-start w-full gap-[23px]">
          <div className="h-[199px] w-full relative">
            <Img
              src="images/img_ellipse_2.png"
              alt="image"
              className="justify-center h-[199px] w-full left-0 bottom-0 right-0 top-0 m-auto object-cover absolute"
            />
            <Text size="xl" as="p" className="left-[2%] top-[16%] m-auto text-shadow-ts absolute">
              Bill book
            </Text>
          </div>
          <div className="flex flex-row justify-between w-full mx-auto max-w-[1037px]">
            <Text as="p">name</Text>
            <div className="flex flex-row justify-between w-auto mb-1 gap-[79px]">
              <Text as="p" className="mt-px">
                Total amount
              </Text>
              <Text as="p">mobile number</Text>
            </div>
          </div>
          <div className="flex flex-col items-center justify-start w-full gap-12 mx-auto max-w-[1558px]">
            <div className="flex flex-row justify-between items-center w-full">
              <div className="flex flex-row justify-between w-[44%]">
                <div className="h-[71px] w-[48%] bg-blue_gray-100" />
                <Input name="amount" className="w-[48%]" />
              </div>
              <div className="h-[71px] w-[21%] bg-blue_gray-100" />
              <div className="flex flex-row justify-center w-[12%] bg-gradient shadow-xs rounded-[16px]">
                <div className="flex flex-col items-center justify-start w-[73%] mt-[7px] mx-[23px]">
                  <Heading as="h1">update</Heading>
                  <Heading as="h2" className="mt-[-54px]">
                    update
                  </Heading>
                </div>
              </div>
              <Button color="lime_400_yellow_500_01" className="min-w-[185px]">
                Delete
              </Button>
            </div>
            <div className="flex flex-row justify-between items-center w-full">
              <div className="flex flex-row justify-between w-[44%]">
                <div className="h-[71px] w-[48%] bg-blue_gray-100" />
                <Input name="edittext" className="w-[48%]" />
              </div>
              <div className="h-[71px] w-[21%] bg-blue_gray-100" />
              <Button color="lime_400_yellow_500_01" className="min-w-[185px]">
                update
              </Button>
              <div className="flex flex-row justify-center w-[12%]">
                <div className="flex flex-col items-start justify-start w-full">
                  <div className="h-[65px] w-full bg-gradient shadow-xs rounded-[16px]" />
                  <Heading as="h3" className="mt-[-51px] ml-[25px]">
                    Delete
                  </Heading>
                </div>
              </div>
            </div>
            <div className="flex flex-row justify-between items-start w-full">
              <div className="flex flex-row justify-between w-[44%]">
                <div className="h-[71px] w-[48%] bg-blue_gray-100" />
                <div className="h-[71px] w-[48%] bg-blue_gray-100" />
              </div>
              <div className="h-[71px] w-[21%] mt-px bg-blue_gray-100" />
              <Button color="lime_400_yellow_500_01" className="mt-px min-w-[185px]">
                update
              </Button>
              <div className="flex flex-row justify-center w-[12%]">
                <div className="flex flex-col items-start justify-start w-full">
                  <Heading as="h4" className="ml-[25px] z-[1]">
                    Delete
                  </Heading>
                  <div className="h-[65px] w-full mt-[-53px] bg-gradient shadow-xs rounded-[16px]" />
                </div>
              </div>
            </div>
            <div className="flex flex-row justify-between items-start w-full">
              <div className="flex flex-row justify-between w-[44%] mt-[3px]">
                <div className="h-[71px] w-[48%] bg-blue_gray-100" />
                <div className="h-[71px] w-[48%] bg-blue_gray-100" />
              </div>
              <div className="h-[71px] w-[21%] mt-[3px] bg-blue_gray-100" />
              <Button color="lime_400_yellow_500_01" className="min-w-[185px]">
                update
              </Button>
              <Button color="lime_400_yellow_500_01" className="mt-[3px] min-w-[185px]">
                Delete
              </Button>
            </div>
            <div className="flex flex-row justify-between items-end w-full">
              <div className="flex flex-row justify-between w-auto mt-1.5 gap-[39px]">
                <Input name="edittext_one" className="w-[48%]" />
                <Input name="edittext_two" className="w-[48%]" />
              </div>
              <div className="h-[71px] w-[21%] bg-blue_gray-100" />
              <Button color="lime_400_yellow_500_01" className="mb-3 min-w-[185px]">
                update
              </Button>
              <Button color="lime_400_yellow_500_01" className="mb-1.5 min-w-[185px]">
                Delete
              </Button>
            </div>
            <div className="flex flex-row justify-between items-start w-full">
              <div className="flex flex-row justify-between w-auto mt-[9px] gap-[39px]">
                <Input name="edittext_three" className="w-[48%]" />
                <Input name="edittext_four" className="w-[48%]" />
              </div>
              <div className="h-[71px] w-[21%] mt-[9px] bg-blue_gray-100" />
              <Button color="lime_400_yellow_500_01" className="min-w-[185px]">
                update
              </Button>
              <Button color="lime_400_yellow_500_01" className="min-w-[185px]">
                Delete
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
