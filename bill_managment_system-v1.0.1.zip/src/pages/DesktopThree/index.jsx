import React from "react";
import { Helmet } from "react-helmet";
import { Button, Input, Text, Img } from "../../components";

export default function DesktopThreePage() {
  return (
    <>
      <Helmet>
        <title>bill managment system</title>
        <meta name="description" content="Web site created using create-react-app" />
      </Helmet>
      <div className="flex flex-row justify-center w-full pb-[77px] bg-white-A700">
        <div className="flex flex-col items-center justify-start w-full">
          <div className="h-[194px] w-full relative">
            <Img
              src="images/img_ellipse_2_194x1440.png"
              alt="image"
              className="justify-center h-[194px] w-full left-0 bottom-0 right-0 top-0 m-auto object-cover absolute"
            />
            <Text size="xl" as="p" className="left-[1%] top-[10%] m-auto text-shadow-ts absolute">
              Bill management system
            </Text>
          </div>
          <div className="flex flex-row justify-between items-center w-full mt-[87px] max-w-[1031px]">
            <Text as="p">Name</Text>
            <Input size="2xl" name="edittext" className="w-[74%]" />
          </div>
          <div className="flex flex-col items-start justify-start w-full mt-[42px] max-w-[1244px]">
            <div className="flex flex-row justify-between items-center w-[90%]">
              <Text as="p">Total amount</Text>
              <div className="h-[101px] w-[68%] bg-blue_gray-100" />
            </div>
            <div className="flex flex-row justify-start items-center mt-[42px] gap-6">
              <Text as="p">mobile number</Text>
              <Input size="2xl" name="edittext_one" className="w-[68%]" />
            </div>
            <Button color="lime_400_yellow_500_01" className="mt-[214px] ml-[1059px] min-w-[185px]">
              Add
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
