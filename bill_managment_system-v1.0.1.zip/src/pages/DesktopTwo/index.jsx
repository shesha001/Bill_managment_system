import React from "react";
import { Helmet } from "react-helmet";
import { Heading, Button, Input, Text, Img } from "../../components";

export default function DesktopTwoPage() {
  return (
    <>
      <Helmet>
        <title>bill managment system</title>
        <meta name="description" content="Web site created using create-react-app" />
      </Helmet>
      <div className="flex flex-row justify-start w-full bg-white-A700">
        <div className="flex flex-row justify-between items-center w-full mx-auto max-w-[1292px]">
          <div className="flex flex-col items-center justify-start w-[56%]">
            <Img src="images/img_ellipse_3.png" alt="image" className="w-[49%] object-cover" />
            <div className="flex flex-row justify-between items-start w-full mt-[30px]">
              <Img src="images/img_ellipse_2_426x274.png" alt="image_one" className="w-[39%] object-cover" />
              <div className="h-[310px] w-[49%] mt-[46px] bg-gradient2 rounded-[50%]" />
            </div>
            <div className="h-[310px] w-[49%] mt-[70px] bg-gradient1 rounded-[50%]" />
          </div>
          <div className="flex flex-col items-center justify-start w-[38%]">
            <div className="flex flex-row justify-center w-[99%]">
              <div className="flex flex-col items-start justify-start w-full">
                <Text size="md" as="p" className="text-shadow-ts1">
                  forgot password ?
                </Text>
                <div className="flex flex-row justify-start items-center mt-6 ml-[9px] gap-[9px]">
                  <Img src="images/img_group.svg" alt="image_two" className="h-[19px]" />
                  <a href="#">
                    <Text size="xs" as="p" className="!text-gray-900">
                      reset password
                    </Text>
                  </a>
                </div>
                <Input color="deep_purple_50_cc" size="xs" shape="round" name="edittext" className="w-full mt-1" />
              </div>
            </div>
            <div className="flex flex-col items-start justify-start w-[99%] mt-[17px] gap-1">
              <Text size="xs" as="p" className="ml-[9px] !text-gray-900">
                re-try password
              </Text>
              <Input color="deep_purple_50_cc" size="sm" shape="round" name="password" className="w-full" />
            </div>
            <div className="flex flex-col items-center justify-start w-[28%] mt-[34px] gap-[129px]">
              <Button size="xs" color="lime_400_yellow_500_01" className="w-full">
                save{" "}
              </Button>
              <Heading size="xs" as="h1">
                Login{" "}
              </Heading>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
